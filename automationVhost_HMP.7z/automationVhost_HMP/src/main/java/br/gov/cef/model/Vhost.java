package br.gov.cef.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Version;

@Entity
public class Vhost implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6155594840160494891L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id", updatable = false, nullable = false)
	private Long id = null;
	@Version
	@Column(name = "version")
	private int version = 0;

	@Column
	private String fqdn;

	@Column
	private String context;
	
	@Column
	private String applicationName;
	
	@Column
	private String balancerName;


	@ManyToOne
	@JoinColumn(name = "ID_VERSIONMODCLUSTER")
	private versionModCluster versionModCluster;

	@ManyToOne
	@JoinColumn(name = "ID_VHOSTENVIROMENT")
	private enviroment vHostEnviroment;

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public int getVersion() {
		return this.version;
	}

	public void setVersion(final int version) {
		this.version = version;
	}

	public enviroment getvHostEnviroment() {
		return vHostEnviroment;
	}

	public void setvHostEnviroment(enviroment vHostEnviroment) {
		this.vHostEnviroment = vHostEnviroment;
	}

	public versionModCluster getVersionModCluster() {
		return versionModCluster;
	}

	public void setVersionModCluster(versionModCluster versionModCluster) {
		this.versionModCluster = versionModCluster;
	}

	
	
	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}
	
	

	public String getBalancerName() {
		return balancerName;
	}

	public void setBalancerName(String balancerName) {
		this.balancerName = balancerName;
	}

	@Override
	public boolean equals(Object that) {
		if (this == that) {
			return true;
		}
		if (that == null) {
			return false;
		}
		if (getClass() != that.getClass()) {
			return false;
		}
		if (id != null) {
			return id.equals(((Vhost) that).id);
		}
		return super.equals(that);
	}

	@Override
	public int hashCode() {
		if (id != null) {
			return id.hashCode();
		}
		return super.hashCode();
	}

	public String getFqdn() {
		return this.fqdn;
	}

	public void setFqdn(final String fqdn) {
		this.fqdn = fqdn;
	}

	public String getContext() {
		return this.context;
	}

	public void setContext(final String context) {
		this.context = context;
	}

	@Override
	public String toString() {
		String result = getClass().getSimpleName() + " ";
		if (fqdn != null && !fqdn.trim().isEmpty())
			result += "fqdn: " + fqdn;
		if (context != null && !context.trim().isEmpty())
			result += ", context: " + context;
		return result;
	}
}