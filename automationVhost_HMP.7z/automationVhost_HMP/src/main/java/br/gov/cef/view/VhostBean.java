package br.gov.cef.view;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateful;
import javax.enterprise.context.Conversation;
import javax.enterprise.context.ConversationScoped;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import br.gov.cef.model.Vhost;
import br.gov.cef.model.enviroment;
import br.gov.cef.model.versionModCluster;

/**
 * Backing bean for Vhost entities.
 * <p/>
 * This class provides CRUD functionality for all Vhost entities. It focuses
 * purely on Java EE 6 standards (e.g. <tt>&#64;ConversationScoped</tt> for
 * state management, <tt>PersistenceContext</tt> for persistence,
 * <tt>CriteriaBuilder</tt> for searches) rather than introducing a CRUD
 * framework or custom base class.
 */

@Named
@Stateful
@ConversationScoped
public class VhostBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final String DIRECTORY_MACHINE1_JBOSS6 = "DIRECTORY_MACHINE1_JBOSS6";
	private static final String DIRECTORY_MACHINE2_JBOSS6 = "DIRECTORY_MACHINE2_JBOSS6";
	
	private static final String DIRECTORY_MACHINE1_JBOSS7 = "DIRECTORY_MACHINE1_JBOSS7";
	private static final String DIRECTORY_MACHINE2_JBOSS7 = "DIRECTORY_MACHINE2_JBOSS7";

	/*
	 * Support creating and retrieving Vhost entities
	 */

	private Long id;

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	private Vhost vhost;

	public Vhost getVhost() {
		return this.vhost;
	}

	public void setVhost(Vhost vhost) {
		this.vhost = vhost;
	}

	@Inject
	private Conversation conversation;

	@PersistenceContext(unitName = "forge-default", type = PersistenceContextType.EXTENDED)
	private EntityManager entityManager;

	public String create() {

		this.conversation.begin();
		this.conversation.setTimeout(1800000L);
		return "create?faces-redirect=true";
	}

	public void retrieve() {

		if (FacesContext.getCurrentInstance().isPostback()) {
			return;
		}

		if (this.conversation.isTransient()) {
			this.conversation.begin();
			this.conversation.setTimeout(1800000L);
		}

		if (this.id == null) {
			this.vhost = this.example;
		} else {
			this.vhost = findById(getId());
		}
	}

	public Vhost findById(Long id) {

		return this.entityManager.find(Vhost.class, id);
	}

	/*
	 * Support updating and deleting Vhost entities
	 */

	public String update() {
		this.conversation.end();

		try {
			if (this.id == null) {
				this.entityManager.persist(this.vhost);
				createVirtualHost();
				return "search?faces-redirect=true";
			} else {
				this.entityManager.merge(this.vhost);
				createVirtualHost();
				return "view?faces-redirect=true&id=" + this.vhost.getId();
			}
		} catch (Exception e) {
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(e.getMessage()));
			return null;
		}
	}

	public String delete() {
		this.conversation.end();

		try {
			Vhost deletableEntity = findById(getId());
			Runtime run = Runtime.getRuntime();
			this.entityManager.remove(deletableEntity);
			this.entityManager.flush();
			String directoryMachine1 = "";
			String directoryMachine2 = "";
			if (vhost.getVersionModCluster().getDescription().equals("eap_des_71")) {
				directoryMachine1 =System.getProperty(DIRECTORY_MACHINE1_JBOSS7);
				directoryMachine2 =System.getProperty(DIRECTORY_MACHINE2_JBOSS7);
			} else {
				directoryMachine1 =System.getProperty(DIRECTORY_MACHINE1_JBOSS6);
				directoryMachine2 =System.getProperty(DIRECTORY_MACHINE2_JBOSS6);
			}
			String linkSimbolico ="";
			if (vhost.getVersionModCluster().getDescription().equals("eap_des_71")) {
				linkSimbolico = directoryMachine1+"/sites-enabled/eap_des_71/"+this.vhost.getVersionModCluster()+"/httpd-"+this.vhost.getFqdn().substring(0,this.vhost.getFqdn().indexOf("."))+".conf";
			} else {
				linkSimbolico = directoryMachine1+"/sites-enabled/"+this.vhost.getVersionModCluster()+"/httpd-"+this.vhost.getFqdn().substring(0,this.vhost.getFqdn().indexOf("."))+".conf";
			}
			run.exec("unlink "+linkSimbolico);
			if (vhost.getVersionModCluster().getDescription().equals("eap_des_71")) {
				linkSimbolico = directoryMachine2+"/sites-enabled/eap_des_71/"+this.vhost.getVersionModCluster()+"/httpd-"+this.vhost.getFqdn().substring(0,this.vhost.getFqdn().indexOf("."))+".conf";
			} else {
				linkSimbolico = directoryMachine2+"/sites-enabled/"+this.vhost.getVersionModCluster()+"/httpd-"+this.vhost.getFqdn().substring(0,this.vhost.getFqdn().indexOf("."))+".conf";
			}
			run.exec("unlink "+linkSimbolico);
			
			return "search?faces-redirect=true";
		} catch (Exception e) {
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(e.getMessage()));
			return null;
		}
	}
	
	

	/*
	 * Support searching Vhost entities with pagination
	 */

	private int page;
	private long count;
	private List<Vhost> pageItems;

	private Vhost example = new Vhost();

	public int getPage() {
		return this.page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getPageSize() {
		return 10;
	}

	public Vhost getExample() {
		return this.example;
	}

	public void setExample(Vhost example) {
		this.example = example;
	}

	public String search() {
		this.page = 0;
		return null;
	}

	public void paginate() {

		CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();

		// Populate this.count

		CriteriaQuery<Long> countCriteria = builder.createQuery(Long.class);
		Root<Vhost> root = countCriteria.from(Vhost.class);
		countCriteria = countCriteria.select(builder.count(root)).where(
				getSearchPredicates(root));
		this.count = this.entityManager.createQuery(countCriteria)
				.getSingleResult();

		// Populate this.pageItems

		CriteriaQuery<Vhost> criteria = builder.createQuery(Vhost.class);
		root = criteria.from(Vhost.class);
		TypedQuery<Vhost> query = this.entityManager.createQuery(criteria
				.select(root).where(getSearchPredicates(root)));
		query.setFirstResult(this.page * getPageSize()).setMaxResults(
				getPageSize());
		this.pageItems = query.getResultList();
	}

	private Predicate[] getSearchPredicates(Root<Vhost> root) {

		CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();
		List<Predicate> predicatesList = new ArrayList<Predicate>();

		enviroment vHostEnviroment = this.example.getvHostEnviroment();
		if (vHostEnviroment != null) {
			predicatesList.add(builder.equal(root.get("vHostEnviroment"),
					vHostEnviroment));
		}
		versionModCluster versionModCluster = this.example
				.getVersionModCluster();
		if (versionModCluster != null) {
			predicatesList.add(builder.equal(root.get("versionModCluster"),
					versionModCluster));
		}
		String fqdn = this.example.getFqdn();
		if (fqdn != null && !"".equals(fqdn)) {
			predicatesList.add(builder.like(
					builder.lower(root.<String> get("fqdn")),
					'%' + fqdn.toLowerCase() + '%'));
		}
		String context = this.example.getContext();
		if (context != null && !"".equals(context)) {
			predicatesList.add(builder.like(
					builder.lower(root.<String> get("context")),
					'%' + context.toLowerCase() + '%'));
		}

		return predicatesList.toArray(new Predicate[predicatesList.size()]);
	}
	
	private void createVirtualHost() throws IOException {
		
		String directoryMachine1 = "";
		String directoryMachine2 = "";
		if (vhost.getVersionModCluster().getDescription().equals("eap_des_71")) {
			directoryMachine1 =System.getProperty(DIRECTORY_MACHINE1_JBOSS7);
			directoryMachine2 =System.getProperty(DIRECTORY_MACHINE2_JBOSS7);
		} else {
			directoryMachine1 =System.getProperty(DIRECTORY_MACHINE1_JBOSS6);
			directoryMachine2 =System.getProperty(DIRECTORY_MACHINE2_JBOSS6);
		}
		Runtime run = Runtime.getRuntime();
		FileWriter fw = null;
		String path ="";
		if (vhost.getVersionModCluster().getDescription().equals("eap_des_71")) {
			fw = new FileWriter(directoryMachine1+"/sites-avaliable/eap_des_71/httpd-"+this.vhost.getFqdn().substring(0,this.vhost.getFqdn().indexOf("."))+".conf");
			writeFile(fw);
			path = "../../sites-avaliable/eap_des_71/httpd-"+this.vhost.getFqdn().substring(0,this.vhost.getFqdn().indexOf("."))+".conf";
			String linkSimbolico = directoryMachine1+"/sites-enabled/"+this.vhost.getVersionModCluster()+"/httpd-"+this.vhost.getFqdn().substring(0,this.vhost.getFqdn().indexOf("."))+".conf";
			run.exec("ln -s "+ path +" "+linkSimbolico);
		} else {
			fw = new FileWriter(directoryMachine1+"/sites-avaliable/httpd-"+this.vhost.getFqdn().substring(0,this.vhost.getFqdn().indexOf("."))+".conf");
			writeFile(fw);
			path = "../../sites-avaliable/httpd-"+this.vhost.getFqdn().substring(0,this.vhost.getFqdn().indexOf("."))+".conf";
			String linkSimbolico = directoryMachine1+"/sites-enabled/"+this.vhost.getVersionModCluster()+"/httpd-"+this.vhost.getFqdn().substring(0,this.vhost.getFqdn().indexOf("."))+".conf";
			run.exec("ln -s "+ path +" "+linkSimbolico);
		}
		fw.close();
		if (vhost.getVersionModCluster().getDescription().equals("eap_des_71")) {
			fw = new FileWriter(directoryMachine2+"/sites-avaliable/eap_des_71/httpd-"+this.vhost.getFqdn().substring(0,this.vhost.getFqdn().indexOf("."))+".conf");
			writeFile(fw);
			path = "../../sites-avaliable/eap_des_71/httpd-"+this.vhost.getFqdn().substring(0,this.vhost.getFqdn().indexOf("."))+".conf";
			String linkSimbolico = directoryMachine2+"/sites-enabled/"+this.vhost.getVersionModCluster()+"/httpd-"+this.vhost.getFqdn().substring(0,this.vhost.getFqdn().indexOf("."))+".conf";
			run.exec("ln -s "+ path +" "+linkSimbolico);
		} else {
			fw = new FileWriter(directoryMachine2+"/sites-avaliable/httpd-"+this.vhost.getFqdn().substring(0,this.vhost.getFqdn().indexOf("."))+".conf");
			writeFile(fw);
			path = "../../sites-avaliable/httpd-"+this.vhost.getFqdn().substring(0,this.vhost.getFqdn().indexOf("."))+".conf";
			String linkSimbolico = directoryMachine2+"/sites-enabled/"+this.vhost.getVersionModCluster()+"/httpd-"+this.vhost.getFqdn().substring(0,this.vhost.getFqdn().indexOf("."))+".conf";
			run.exec("ln -s "+ path +" "+linkSimbolico);
		}
		
			
	}

	private void writeFile(FileWriter fw) throws IOException {
		BufferedWriter buffW = new BufferedWriter (fw);
		writeVIPJBoss(buffW);
		
		buffW.newLine();
		buffW.write("<VirtualHost *:80>");
		buffW.newLine();
		buffW.write("	ServerName  "+this.vhost.getFqdn());
		buffW.newLine();
		buffW.newLine();
		buffW.write("	RewriteEngine On");
		buffW.newLine();
		buffW.write("	RewriteRule ^/$ /"+this.vhost.getContext()+" [R]");
		buffW.newLine();
		buffW.newLine();
		buffW.write("	RewriteRule ^/"+this.vhost.getContext()+"$ /"+this.vhost.getContext()+"/ [R]");
		buffW.newLine();
		buffW.write("	ProxyPass ^/"+this.vhost.getContext()+"/ balancer://"+this.vhost.getBalancerName()+"/"+this.vhost.getContext()+"/ stickysession=JSESSIONID|jsessionid nofailover=On");
		buffW.newLine();
		buffW.write("	ProxyPassReverse ^/"+this.vhost.getContext()+"/ balancer://"+this.vhost.getBalancerName()+"/"+this.vhost.getContext()+"/");
		buffW.newLine();
		buffW.write("	<Location /balancer-manager>");
		buffW.newLine();
		buffW.write("   		SetHandler balancer-manager");
		buffW.newLine();
		if (vhost.getVersionModCluster().getDescription().equals("eap_des_71")) {
			buffW.write("   		Require all granted");
			buffW.newLine();
		} else {
			buffW.write("   		Order deny,allow");
			buffW.newLine();
			buffW.write("   		Allow from 10.0.0.0");
			buffW.newLine();
		}
		buffW.write("	</Location>");
		buffW.newLine();
		buffW.newLine();
		buffW.write("	CustomLog /logs/apache2/"+this.getVhost().getApplicationName()+"/"+this.vhost.getFqdn()+"-access.log combined");
		buffW.newLine();
		buffW.write("	ErrorLog /logs/apache2/"+this.getVhost().getApplicationName()+"/"+this.vhost.getFqdn()+"-error.log");
		buffW.newLine();
		buffW.write("</VirtualHost>");
		buffW.close();
	}

	private void writeVIPJBoss(BufferedWriter buffW) throws IOException {
		if (vhost.getVersionModCluster().getDescription().equals("eap_des_64")) {
			buffW.write("# VIP Compartilhado: 10.116.80.21");
		}
		if (vhost.getVersionModCluster().getDescription().equals("eap_prodt_64") || vhost.getVersionModCluster().getDescription().equals("eap_des_financeiro_64")) {
			buffW.write("# VIP Compartilhado: 10.116.80.202");
		}
		if (vhost.getVersionModCluster().getDescription().equals("eap_des_71")) {
			buffW.write("# VIP Compartilhado: 10.116.80.1");
		}
	}

	public List<Vhost> getPageItems() {
		return this.pageItems;
	}

	public long getCount() {
		return this.count;
	}

	/*
	 * Support listing and POSTing back Vhost entities (e.g. from inside an
	 * HtmlSelectOneMenu)
	 */

	public List<Vhost> getAll() {

		CriteriaQuery<Vhost> criteria = this.entityManager.getCriteriaBuilder()
				.createQuery(Vhost.class);
		return this.entityManager.createQuery(
				criteria.select(criteria.from(Vhost.class))).getResultList();
	}

	@Resource
	private SessionContext sessionContext;

	public Converter getConverter() {

		final VhostBean ejbProxy = this.sessionContext
				.getBusinessObject(VhostBean.class);

		return new Converter() {

			@Override
			public Object getAsObject(FacesContext context,
					UIComponent component, String value) {

				return ejbProxy.findById(Long.valueOf(value));
			}

			@Override
			public String getAsString(FacesContext context,
					UIComponent component, Object value) {

				if (value == null) {
					return "";
				}

				return String.valueOf(((Vhost) value).getId());
			}
		};
	}

	/*
	 * Support adding children to bidirectional, one-to-many tables
	 */

	private Vhost add = new Vhost();

	public Vhost getAdd() {
		return this.add;
	}

	public Vhost getAdded() {
		Vhost added = this.add;
		this.add = new Vhost();
		return added;
	}
}
