/* Apaga tabelas já criadas. */
DROP TABLE IF EXISTS contatos CASCADE;
DROP TABLE IF EXISTS usuarios CASCADE;

/*INSERT INTO contatos (nome, telefone, celular, email, dataNascimento, endereco, cidade, uf)*/
CREATE TABLE contatos (
	id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY, 
	nome VARCHAR(100) NOT NULL, 
	telefone VARCHAR(20), 
	celular VARCHAR(20), 
	email VARCHAR(100), 
	dataNascimento DATE, 
	endereco VARCHAR(500), 
	cidade VARCHAR(20), 
	uf VARCHAR(50),
	sexo VARCHAR(1)
)

CREATE TABLE usuarios (
	id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY, 
	login VARCHAR(100) NOT NULL,
	senha VARCHAR(100) NOT NULL
)

/*INSERT INTO contatos (nome, telefone, celular, email, dataNascimento, endereco, cidade, uf)*/