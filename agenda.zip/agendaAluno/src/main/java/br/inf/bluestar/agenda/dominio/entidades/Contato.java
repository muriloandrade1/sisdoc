package br.inf.bluestar.agenda.dominio.entidades;

import java.util.Calendar;

import br.inf.bluestar.agenda.dominio.uteis.EmailValidator;

public class Contato {

	private Long id;
	private String nome;
	private String email;
	private String telefone;
	private String celular;
	private Calendar dataDeNascimento;
	private String cidade;
	private String uf;
	private String endereco;
	private Sexo sexo;

	public String getNome() {

		return nome;
	}

	public void setNome(String nome) {

		if (nome != null && nome.length() >= 5) {
			this.nome = nome;
		} else {
			throw new IllegalArgumentException(
					"Nome deve ter ao menos 5 caracteres");
		}
	}

	public String getEmail() {

		return email;
	}

	public void setEmail(String email) {

		if (email != null && new EmailValidator().validate(email)) {
			this.email = email;
		} else {
			throw new IllegalArgumentException("Endereço de E-mail Inválido");
		}
	}

	public String getTelefone() {

		return telefone;
	}

	public void setTelefone(String telefone) {

		this.telefone = telefone;
	}

	public String getCelular() {

		return celular;
	}

	public void setCelular(String celular) {

		this.celular = celular;
	}

	public Calendar getDataDeNascimento() {

		return dataDeNascimento;
	}

	public void setDataDeNascimento(Calendar dataDeNascimento) {

		this.dataDeNascimento = dataDeNascimento;
	}

	public String getCidade() {

		return cidade;
	}

	public void setCidade(String cidade) {

		this.cidade = cidade;
	}

	public String getUf() {

		return uf;
	}

	public void setUf(String uf) {

		this.uf = uf;
	}

	public String getEndereco() {

		return endereco;
	}

	public void setEndereco(String endereco) {

		this.endereco = endereco;
	}

	@Override
	public String toString() {

		return "Contato [id =" + id + " nome=" + nome + ", email=" + email
				+ ", telefone=" + telefone + ", celular=" + celular
				+ ", dataDeNascimento=" + dataDeNascimento + ", cidade="
				+ cidade + ", uf=" + uf + ", endereco=" + endereco + "]";
	}

	public Long getId() {

		return id;
	}

	public void setId(Long id2) {

		this.id = id2;
	}

	public void setSexo(Sexo sexo) {

		this.sexo = sexo;
	}

	public Sexo getSexo() {

		return this.sexo;
	}

}
