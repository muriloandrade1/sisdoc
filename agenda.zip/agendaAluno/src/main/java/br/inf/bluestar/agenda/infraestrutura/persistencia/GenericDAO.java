package br.inf.bluestar.agenda.infraestrutura.persistencia;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.List;

public interface GenericDAO<T, ID extends Serializable> {
	T buscarPorId(ID id, boolean lock) throws SQLException;
	List<T> buscarTodos() throws SQLException;
	List<T> buscarPorExemplo(T instanciaDeExemplo, String[] propriedadesAExcluir);
	T salvarOuAtualizar (T entidade) throws SQLException;
	void excluir (T entidade) throws SQLException;
}

