package br.inf.bluestar.agenda.infraestrutura.uteis;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import br.inf.bluestar.agenda.aplicacao.services.AgendaService;
import br.inf.bluestar.agenda.infraestrutura.persistencia.BancoUtil;

public class InicializaBanco implements
		ServletContextListener {

	public void contextInitialized(final ServletContextEvent contextoEvent) {

		try {
			// TODO: Testar se o banco está funcionando!
			AgendaService service = new AgendaService();
			service.obterContatos();
		} catch (Exception e) {
			BancoUtil.instalaBanco(contextoEvent.getServletContext());
		}
	}

	public void contextDestroyed(ServletContextEvent arg0) {

	}

}
