package br.inf.bluestar.agenda.infraestrutura.persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import br.inf.bluestar.agenda.dominio.entidades.Usuario;

public class UsuarioDAOJDBC implements IUsuarioDAO {

	private static final String	SQL_INSERT				= "INSERT INTO usuarios (login, senha) VALUES (?,?);";
	private static final String	SQL_LIST_ALL			= "SELECT * FROM usuarios;";
	private static final String	SQL_GET					= "SELECT * FROM usuarios WHERE id = ?;";
	private static final String	SQL_GET_LOGIN_E_SENHA	= "SELECT * FROM usuarios WHERE login = ? AND senha =?;";
	private static final String	SQL_DELETE				= "DELETE FROM usuarios WHERE id = ?;";
	private static final String	SQL_UPDATE				= "UPDATE usuarios SET login = ?, senha = ? WHERE id = ?;";
	private Connection			conexao;

	@Override
	public void setConexao(final Connection conexao) {

		this.conexao = conexao;
	}

	@Override
	public Connection getConexao() {

		return this.conexao;
	}

	@Override
	public Usuario buscarPorId(final Long id, final boolean lock) throws SQLException {

		Usuario usuario = null;

		final PreparedStatement s = getConexao().prepareStatement(SQL_GET);

		s.setLong(1, id);

		final ResultSet rs = s.executeQuery();

		while (rs.next()) {

			usuario = new Usuario();

			usuario.setId(rs.getLong("id"));
			usuario.setLogin(rs.getString("login"));
			usuario.setSenha(rs.getString("senha"));

		}

		rs.close();
		s.close();

		return usuario;
	}

	@Override
	public List<Usuario> buscarTodos() throws SQLException {

		final List<Usuario> usuarios = new ArrayList<Usuario>();

		final PreparedStatement s = this.conexao.prepareStatement(SQL_LIST_ALL);

		final ResultSet rs = s.executeQuery();

		while (rs.next()) {

			final Usuario usuario = new Usuario();

			usuario.setId(rs.getLong("id"));
			usuario.setLogin(rs.getString("login"));
			usuario.setSenha(rs.getString("senha"));

			usuarios.add(usuario);
		}

		rs.close();
		s.close();

		return usuarios;

	}

	@Override
	public List<Usuario> buscarPorExemplo(final Usuario instanciaDeExemplo, final String[] propriedadesAExcluir) {

		throw new RuntimeException("Método ainda não implementado!");
		// TODO Auto-generated method stub
		// return null;
	}

	@Override
	public Usuario salvarOuAtualizar(Usuario usuario) throws SQLException {

		if (usuario.getId() == null) {

			final PreparedStatement s = this.conexao.prepareStatement(SQL_INSERT);

			s.setString(1, usuario.getLogin());
			s.setString(2, usuario.getSenha());

			s.execute();

			final Statement stId = this.conexao.createStatement();
			stId.execute("call IDENTITY()");
			final ResultSet resultSet = stId.getResultSet();
			while (resultSet.next()) {
				final Long id = resultSet.getLong(1);
				usuario.setId(id);
			}

		} else {

			final PreparedStatement s = this.conexao.prepareStatement(SQL_UPDATE);

			s.setString(1, usuario.getLogin());
			s.setString(2, usuario.getSenha());
			s.setLong(3, usuario.getId());

			s.execute();

			usuario = buscarPorId(usuario.getId(), false);

		}

		return usuario;
	}

	@Override
	public void excluir(final Usuario usuario) throws SQLException {

		final PreparedStatement s = this.conexao.prepareStatement(SQL_DELETE);

		s.setLong(1, usuario.getId());

		s.execute();

	}

	public Usuario buscarUsuarioPorLoginESenha(final Usuario usuario) throws SQLException {

		Usuario u = null;

		final PreparedStatement s = getConexao().prepareStatement(SQL_GET_LOGIN_E_SENHA);

		s.setString(1, usuario.getLogin());
		s.setString(2, usuario.getSenha());

		final ResultSet rs = s.executeQuery();

		while (rs.next()) {

			u = new Usuario();

			u.setId(rs.getLong("id"));
			u.setLogin(rs.getString("login"));
			u.setSenha(rs.getString("senha"));

		}

		rs.close();
		s.close();

		return u;
	}

}
