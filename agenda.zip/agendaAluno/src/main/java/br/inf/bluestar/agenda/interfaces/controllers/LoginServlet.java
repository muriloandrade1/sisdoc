package br.inf.bluestar.agenda.interfaces.controllers;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.inf.bluestar.agenda.aplicacao.services.UsuarioService;
import br.inf.bluestar.agenda.dominio.entidades.Usuario;

public class LoginServlet extends HttpServlet {

	private static final long		serialVersionUID	= 7286034401388216L;
	private final UsuarioService	service				= new UsuarioService();

	@Override
	protected void service(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {

		serve(request, response);

	}

	private void serve(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {

		Usuario usuario = construirUsuario(request);

		final RequestDispatcher rd = request.getRequestDispatcher("WEB-INF/login.jsp");

		final String acao = request.getParameter("acao");

		if (acao == null || !acao.equals("logoff")) {

			if (usuario.getLogin() == null || usuario.getSenha() == null) {
				rd.forward(request, response);
			} else {
				try {
					usuario = this.service.buscarUsuarioPorLoginESenha(usuario);
				} catch (final SQLException e) {
					e.printStackTrace();
				}
			}

		}

	}

	private Usuario construirUsuario(final HttpServletRequest request) {

		final Usuario usuario = new Usuario();

		final String senha = request.getParameter("senha");
		usuario.setSenha(senha);

		final String login = request.getParameter("login");
		usuario.setLogin(login);

		// TODO Auto-generated method stub
		return usuario;
	}

}
