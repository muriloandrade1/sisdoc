package br.inf.bluestar.agenda.aplicacao.services;

import java.sql.SQLException;

import br.inf.bluestar.agenda.dominio.entidades.Usuario;
import br.inf.bluestar.agenda.dominio.repositorios.UsuarioRepositorio;

public class UsuarioService {

	UsuarioRepositorio	repo	= new UsuarioRepositorio();

	public Usuario buscarUsuarioPorLoginESenha(final Usuario usuario) throws SQLException {

		return this.repo.buscarUsuarioPorLoginESenha(usuario);
	}

}
