package br.inf.bluestar.agenda.dominio.repositorios;

import java.sql.SQLException;

import br.inf.bluestar.agenda.dominio.entidades.Usuario;
import br.inf.bluestar.agenda.infraestrutura.persistencia.UsuarioDAOJDBC;

public class UsuarioRepositorio {

	UsuarioDAOJDBC	dao	= new UsuarioDAOJDBC();

	public Usuario buscarUsuarioPorLoginESenha(final Usuario usuario) throws SQLException {

		return this.dao.buscarUsuarioPorLoginESenha(usuario);
	}

}
