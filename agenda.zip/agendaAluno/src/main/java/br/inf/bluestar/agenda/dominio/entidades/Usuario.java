package br.inf.bluestar.agenda.dominio.entidades;

/**
 * The Class Usuario.
 */
public class Usuario {

	/** The senha. */
	private String	senha;

	/** The login. */
	private String	login;

	private Long	id;

	/**
	 * Sets the senha.
	 * 
	 * @param senha
	 *            the new senha
	 */
	public void setSenha(final String senha) {

		this.senha = senha;
	}

	/**
	 * Sets the login.
	 * 
	 * @param login
	 *            the new login
	 */
	public void setLogin(final String login) {

		this.login = login;
	}

	/**
	 * Gets the senha.
	 * 
	 * @return the senha
	 */
	public String getSenha() {

		return this.senha;
	}

	/**
	 * Gets the login.
	 * 
	 * @return the login
	 */
	public String getLogin() {

		return this.login;
	}

	public void setId(final Long id) {

		this.id = id;
	}

	/**
	 * Gets the id.
	 * 
	 * @return the id
	 */
	public Long getId() {

		return this.id;
	}

}
