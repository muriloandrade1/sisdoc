package br.inf.bluestar.agenda.infraestrutura.persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import br.inf.bluestar.agenda.dominio.entidades.Contato;
import br.inf.bluestar.agenda.dominio.entidades.Sexo;
import br.inf.bluestar.agenda.infraestrutura.uteis.DataUtil;

public class ContatoDAOJDBC implements IContatoDAO {

	private static final String SQL_INSERT = "INSERT INTO contatos (nome, telefone, celular, email, dataNascimento, endereco, cidade, uf, sexo) VALUES (?,?,?,?,?,?,?,?,?);";
	private static final String SQL_LIST_ALL = "SELECT * FROM contatos;";
	private static final String SQL_GET = "SELECT * FROM contatos WHERE id = ?;";
	private static final String SQL_DELETE = "DELETE FROM contatos WHERE id = ?;";
	private static final String SQL_UPDATE = "UPDATE contatos SET nome = ?, telefone = ?, celular = ?, email = ?, dataNascimento = ?, endereco = ?, cidade = ?, uf = ?, sexo = ? WHERE id = ?;";
	private Connection conexao;

	public void setConexao(Connection conexao) {

		this.conexao = conexao;
	}

	@Override
	public Connection getConexao() {

		return conexao;
	}

	@Override
	public Contato buscarPorId(Long id, boolean lock) throws SQLException {

		Contato contato = null;

		PreparedStatement s = getConexao().prepareStatement(SQL_GET);

		s.setLong(1, id);

		ResultSet rs = s.executeQuery();

		while (rs.next()) {

			contato = new Contato();

			contato.setId(rs.getLong("id"));
			contato.setNome(rs.getString("nome"));
			contato.setTelefone(rs.getString("telefone"));
			contato.setCelular(rs.getString("celular"));
			contato.setEmail(rs.getString("email"));
			if (rs.getDate("dataNascimento") != null) {
				contato.setDataDeNascimento(DataUtil.converteDataSQLCalendar(rs
						.getDate("dataNascimento")));
			}
			contato.setEndereco(rs.getString("endereco"));
			contato.setCidade(rs.getString("cidade"));
			contato.setUf(rs.getString("uf"));
			String sexoString = rs.getString("sexo");
			if (sexoString != null && !sexoString.equals("")) {
				Sexo sexo = Sexo.getSexoPorCodigo(sexoString);
				contato.setSexo(sexo);
			}
		}

		rs.close();
		s.close();

		return contato;
	}

	@Override
	public List<Contato> buscarTodos() throws SQLException {

		List<Contato> contatos = new ArrayList<Contato>();

		PreparedStatement s = conexao.prepareStatement(SQL_LIST_ALL);

		ResultSet rs = s.executeQuery();

		while (rs.next()) {

			Contato contato = new Contato();

			contato.setId(rs.getLong("id"));
			contato.setNome(rs.getString("nome"));
			contato.setTelefone(rs.getString("telefone"));
			contato.setCelular(rs.getString("celular"));
			contato.setEmail(rs.getString("email"));
			if (rs.getDate("dataNascimento") != null) {
				contato.setDataDeNascimento(DataUtil.converteDataSQLCalendar(rs
						.getDate("dataNascimento")));
			}
			contato.setEndereco(rs.getString("endereco"));
			contato.setCidade(rs.getString("cidade"));
			contato.setUf(rs.getString("uf"));
			String sexoString = rs.getString("sexo");
			if (sexoString != null && !sexoString.equals("")) {
				Sexo sexo = Sexo.getSexoPorCodigo(sexoString);
				contato.setSexo(sexo);
			}

			contatos.add(contato);
		}

		rs.close();
		s.close();

		return contatos;

	}

	@Override
	public List<Contato> buscarPorExemplo(Contato instanciaDeExemplo,
			String[] propriedadesAExcluir) {

		throw new RuntimeException("Método ainda não implementado!");
		// TODO Auto-generated method stub
		// return null;
	}

	@Override
	public Contato salvarOuAtualizar(Contato contato) throws SQLException {

		if (contato.getId() == null) {

			PreparedStatement s = conexao.prepareStatement(SQL_INSERT);

			s.setString(1, contato.getNome());
			s.setString(2, contato.getTelefone());
			s.setString(3, contato.getCelular());
			s.setString(4, contato.getEmail());
			if (contato.getDataDeNascimento() != null) {
				s.setDate(5, DataUtil.converteDataCalendarSQL(contato
						.getDataDeNascimento()));
			} else {
				s.setDate(5, null);
			}
			s.setString(6, contato.getEndereco());
			s.setString(7, contato.getCidade());
			s.setString(8, contato.getUf());
			if (contato.getSexo() != null) {
				s.setString(9, contato.getSexo().getCodigo());
			} else {
				s.setString(9, null);
			}
			s.execute();

			Statement stId = conexao.createStatement();
			stId.execute("call IDENTITY()");
			ResultSet resultSet = stId.getResultSet();
			while (resultSet.next()) {
				Long id = resultSet.getLong(1);
				contato.setId(id);
			}

		} else {

			PreparedStatement s = conexao.prepareStatement(SQL_UPDATE);

			s.setString(1, contato.getNome());
			s.setString(2, contato.getTelefone());
			s.setString(3, contato.getCelular());
			s.setString(4, contato.getEmail());
			if (contato.getDataDeNascimento() != null) {
				s.setDate(5, DataUtil.converteDataCalendarSQL(contato
						.getDataDeNascimento()));
			} else {
				s.setDate(5, null);
			}
			s.setString(6, contato.getEndereco());
			s.setString(7, contato.getCidade());
			s.setString(8, contato.getUf());
			if (contato.getSexo() != null) {
				s.setString(9, contato.getSexo().getCodigo());
			} else {
				s.setString(9, null);
			}
			s.setLong(10, contato.getId());

			s.execute();

			contato = buscarPorId(contato.getId(), false);

		}

		return contato;
	}

	@Override
	public void excluir(Contato contato) throws SQLException {

		PreparedStatement s = conexao.prepareStatement(SQL_DELETE);

		s.setLong(1, contato.getId());

		s.execute();

	}

}
