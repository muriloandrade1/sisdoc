package br.inf.bluestar.agenda.aplicacao.filtros;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import br.inf.bluestar.agenda.dominio.entidades.Usuario;

public class SegurancaFiltro implements Filter {

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	@Override
	public void doFilter(final ServletRequest request, final ServletResponse response, final FilterChain chain) throws IOException, ServletException {

		final HttpServletRequest req = (HttpServletRequest) request;

		final Usuario usuario = (Usuario) req.getSession().getAttribute("logado");

		if (usuario != null) {

			chain.doFilter(request, response);

		} else {

			final RequestDispatcher rd = req.getRequestDispatcher("login");
			rd.forward(req, response);
		}

	}

	@Override
	public void destroy() {

	}

	@Override
	public void init(final FilterConfig arg0) throws ServletException {

	}

}
