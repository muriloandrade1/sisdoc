package br.inf.bluestar.agenda.interfaces.controllers;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.inf.bluestar.agenda.aplicacao.services.AgendaService;
import br.inf.bluestar.agenda.dominio.builders.ContatoBuilder;
import br.inf.bluestar.agenda.dominio.entidades.Contato;
import br.inf.bluestar.agenda.dominio.entidades.Sexo;
import br.inf.bluestar.agenda.infraestrutura.uteis.DataUtil;

public class ContatoServlet extends HttpServlet {

	private static final long serialVersionUID = 3059200073515351079L;
	private AgendaService agendaService = new AgendaService();

	@Override
	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		String acao = request.getParameter("acao");

		if (acao == null) {
			acao = "";
		}

		switch (acao) {

		case "excluir":

			doDelete(request, response);

			break;

		case "editar":

			doPut(request, response);

			break;

		default:

			super.service(request, response);

			break;
		}

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		try {
			Contato contato = construirContato(request);
			contato = agendaService.salvarOuAtualizar(contato);

			reenviarRequisicaoParaAListaDeContatos(response);

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	protected void doPut(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		try {
			Contato contato = construirContato(request);
			contato = agendaService.salvarOuAtualizar(contato);

			reenviarRequisicaoParaAListaDeContatos(response);

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	protected void doDelete(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		try {
			Contato contato = new Contato();
			String idString = request.getParameter("id");
			if (idString != null) {
				Long id = Long.parseLong(idString);
				contato.setId(id);
				agendaService.excluir(contato);

				reenviarRequisicaoParaAListaDeContatos(response);

			} else {
				throw new RuntimeException(
						"É necessário um ID para fazer a exclusão!");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		try {

			String idString = request.getParameter("id");

			if (idString != null) {
				Long id = Long.parseLong(idString);
				Contato contato = agendaService.obterContato(id);

				// Adiconar na requisição o contato:
				request.setAttribute("contato", contato);

				// Redirecionar para o JSP:
				RequestDispatcher rd = request
						.getRequestDispatcher("formulario.jsp");

				rd.forward(request, response);

			} else {
				// Pego os contatos no banco
				List<Contato> contatos = agendaService.obterContatos();

				// Adiciono os contatos na requisição
				request.setAttribute("contatos", contatos);

				// redirecionar a requisição para o lista.jsp
				RequestDispatcher rd = request
						.getRequestDispatcher("lista.jsp");

				rd.forward(request, response);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	private Contato construirContato(HttpServletRequest request) {

		Calendar dataNascimento = DataUtil.converteDataStringCalendar(request
				.getParameter("dataNascimento"));

		String sexoString = request.getParameter("sexo");
		Sexo sexo = null;
		if (sexoString.equals("m") || sexoString.equals("f")) {
			sexo = Sexo.getSexoPorCodigo(sexoString);
		}

		Long id = null;

		if (request.getParameter("id") != null) {
			id = Long.parseLong(request.getParameter("id"));
		}

		Contato contato = new ContatoBuilder().comId(id)
				.comNome(request.getParameter("nome"))
				.celular(request.getParameter("celular"))
				.cidade(request.getParameter("cidade"))
				.email(request.getParameter("email"))
				.endereco(request.getParameter("endereco"))
				.nascidoEm(dataNascimento)
				.telefone(request.getParameter("telefone"))
				.uf(request.getParameter("uf")).sexo(sexo).constroi();

		return contato;
	}

	private void reenviarRequisicaoParaAListaDeContatos(
			HttpServletResponse response) throws IOException {
		response.sendRedirect("contato");
	}
}
