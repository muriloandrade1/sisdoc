package br.inf.bluestar.agenda.dominio.entidades;

public enum Sexo {
	MASCULINO("M", "Masculino"),
	FEMININO("F", "Feminino");

	private Sexo(String codigo, String descricao) {

		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static Sexo getSexoPorCodigo(String codigo) {

		if (codigo.equalsIgnoreCase("f")) {
			return Sexo.FEMININO;
		} else if (codigo.equalsIgnoreCase("m")) {
			return Sexo.MASCULINO;
		} else {
			throw new IllegalArgumentException("Código Inválido para a criação do Sexo - Deve ser 'm' ou 'f'");
		}

	}

	private String	codigo;
	private String	descricao;

	// getters, não precisa de setters

	public String getCodigo() {

		return codigo;
	}

	public String getDescricao() {

		return descricao;
	}

}
