package br.inf.bluestar.agenda.dominio.builders;

import java.util.Calendar;

import br.inf.bluestar.agenda.dominio.entidades.Contato;
import br.inf.bluestar.agenda.dominio.entidades.Sexo;

public class ContatoBuilder {

	private String nome, email, telefone, celular, endereco, cidade, uf;
	private Calendar dataNascimento;
	private Sexo sexo;
	private Long id;

	public ContatoBuilder comNome(String nome) {

		this.nome = nome;
		return this;
	}

	public ContatoBuilder email(String email) {

		this.email = email;
		return this;
	}

	public ContatoBuilder telefone(String telefone) {

		this.telefone = telefone;
		return this;
	}

	public ContatoBuilder celular(String celular) {

		this.celular = celular;
		return this;
	}

	public ContatoBuilder endereco(String endereco) {

		this.endereco = endereco;
		return this;
	}

	public ContatoBuilder cidade(String cidade) {

		this.cidade = cidade;
		return this;
	}

	public ContatoBuilder uf(String uf) {

		this.uf = uf;
		return this;
	}

	public ContatoBuilder nascidoEm(Calendar dataNascimento) {

		this.dataNascimento = dataNascimento;
		return this;
	}

	public ContatoBuilder sexo(Sexo sexo) {

		this.sexo = sexo;

		return this;
	}

	public Contato constroi() {

		Contato contato = new Contato();

		contato.setId(id);
		contato.setCelular(celular);
		contato.setCidade(cidade);
		contato.setDataDeNascimento(dataNascimento);
		contato.setEmail(email);
		contato.setEndereco(endereco);
		contato.setNome(nome);
		contato.setTelefone(telefone);
		contato.setUf(uf);
		contato.setSexo(sexo);

		return contato;
	}

	public ContatoBuilder comId(Long id) {

		this.id = id;

		return this;
	}

}
