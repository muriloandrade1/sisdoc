package br.inf.bluestar.agenda.aplicacao.services;

import java.sql.SQLException;
import java.util.List;

import br.inf.bluestar.agenda.dominio.entidades.Contato;
import br.inf.bluestar.agenda.dominio.repositorios.ContatoRepositorio;

public class AgendaService {

	private ContatoRepositorio repo = new ContatoRepositorio();

	public List<Contato> obterContatos() throws SQLException {
		return repo.listarTodos();
	}

	public Contato salvarOuAtualizar(Contato contato) throws SQLException {
		return repo.salvarOuAtualizar(contato);
	}

	public void excluir(Contato contato) throws SQLException {
		repo.excluir(contato);
	}

	public Contato obterContato(Long id) throws SQLException {
		return repo.obterContato(id);
	}
}

