package br.inf.bluestar.agenda.infraestrutura.persistencia;

import java.sql.Connection;

import br.inf.bluestar.agenda.dominio.entidades.Contato;

public interface IContatoDAO extends GenericDAO<Contato, Long> {

	public Connection getConexao();

	public void setConexao(Connection conexao);
}
