package br.inf.bluestar.agenda.infraestrutura.factory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexaoFabrica {

	private static final String URL_PRODUCAO = 
			"jdbc:hsqldb:file:~/baseAgenda.db;shutdown=true";
	private static final String DRIVER = "org.hsqldb.jdbcDriver";
	private static final String USUARIO = "SA";
	private static final String SENHA = "";

	public static Connection obtemConexaoProducao() {

		try {
			Class.forName(DRIVER);
			Connection c = DriverManager.getConnection(URL_PRODUCAO, USUARIO,
					SENHA);
			return c;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("Erro de conexão com o banco");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			throw new RuntimeException(
					"Não foi possível encontrar o Driver de conexão "
					+ "com o banco de dados");
		}

	}
}



