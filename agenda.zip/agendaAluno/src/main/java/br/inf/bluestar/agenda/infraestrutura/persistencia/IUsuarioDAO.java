package br.inf.bluestar.agenda.infraestrutura.persistencia;

import java.sql.Connection;

import br.inf.bluestar.agenda.dominio.entidades.Usuario;

public interface IUsuarioDAO extends GenericDAO<Usuario, Long> {

	public Connection getConexao();

	public void setConexao(Connection conexao);
}
