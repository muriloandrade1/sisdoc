package br.inf.bluestar.agenda.infraestrutura.uteis;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class DataUtil {
	public static Calendar converteCalendar(String dataString){
		
		if(dataString == null){
			throw new RuntimeException("Data Inválida");
		}
	
			DateFormat formatter;
			Date date;
			formatter = new SimpleDateFormat("dd/MM/yyyy");
			try {
				date = (Date) formatter.parse(dataString);
			
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			
			return cal;
			
			} catch (ParseException e) {
				
				e.printStackTrace();
				throw new RuntimeException("Data inválida");
			}
		
	}
	
	public static Calendar converteDataStringCalendar(String dataString){
		if (dataString == null){
			throw new RuntimeException("Data Inválida!");
		}
		
		try{
			DateFormat formatter;
			Date date;
			formatter = new SimpleDateFormat("dd/MM/yyyy");
			date = (Date) formatter.parse(dataString);
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			
			return cal;
		}catch(ParseException e){
			e.printStackTrace();
			throw new RuntimeException("Data Inválida!");
		}
	}
	
	public static Calendar converteDataSQLCalendar(java.sql.Date data){
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(data.getTime());
		
		return cal;
	}
	
	public static java.sql.Date converteDataCalendarSQL(Calendar data){
		
		java.sql.Date dataSQL = new java.sql.Date(data.getTimeInMillis());
		
		return dataSQL;
	}
	
	public static String formataDataCalendarDDMMYYYY(Calendar data){
		
		String DATE_FORMAT = "dd/MM/yyyy";
		SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
		return sdf.format(data.getTime());
	}
	
}

