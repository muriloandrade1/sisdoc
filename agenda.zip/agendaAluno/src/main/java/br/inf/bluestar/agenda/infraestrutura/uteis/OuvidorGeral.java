package br.inf.bluestar.agenda.infraestrutura.uteis;

import javax.servlet.ServletContextAttributeEvent;
import javax.servlet.ServletContextAttributeListener;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.ServletRequestAttributeEvent;
import javax.servlet.ServletRequestAttributeListener;
import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.http.HttpSessionActivationListener;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

public class OuvidorGeral implements ServletContextListener, ServletContextAttributeListener, HttpSessionListener, HttpSessionAttributeListener,
		HttpSessionActivationListener, HttpSessionBindingListener, ServletRequestListener, ServletRequestAttributeListener {

	public void requestDestroyed(ServletRequestEvent sre) {

		// System.out.println("Ouvidor Geral: requestDestroyed");
	}

	public void attributeAdded(HttpSessionBindingEvent event) {

		// System.out.println("Ouvidor Geral: attributeAdded");
	}

	public void contextInitialized(ServletContextEvent sce) {

		// System.out.println("Ouvidor Geral: contextInitialized");
	}

	public void sessionDidActivate(HttpSessionEvent se) {

		// System.out.println("Ouvidor Geral: sessionDidActivate");
	}

	public void valueBound(HttpSessionBindingEvent event) {

		// System.out.println("Ouvidor Geral: sessionDidActivate");
	}

	public void attributeAdded(ServletContextAttributeEvent event) {

		// System.out.println("Ouvidor Geral: attributeAdded");
	}

	public void attributeRemoved(ServletContextAttributeEvent event) {

		// System.out.println("Ouvidor Geral: attributeRemoved");
	}

	public void sessionDestroyed(HttpSessionEvent se) {

		// System.out.println("Ouvidor Geral: sessionDestroyed");
	}

	public void attributeRemoved(HttpSessionBindingEvent event) {

		// System.out.println("Ouvidor Geral: attributeRemoved");
	}

	public void attributeAdded(ServletRequestAttributeEvent srae) {

		// System.out.println("Ouvidor Geral: attributeAdded");
	}

	public void valueUnbound(HttpSessionBindingEvent event) {

		// System.out.println("Ouvidor Geral: valueUnbound");
	}

	public void sessionWillPassivate(HttpSessionEvent se) {

		// System.out.println("Ouvidor Geral: sessionWillPassivate");
	}

	public void sessionCreated(HttpSessionEvent se) {

		// System.out.println("Ouvidor Geral: sessionCreated");
	}

	public void attributeReplaced(HttpSessionBindingEvent event) {

		// System.out.println("Ouvidor Geral: attributeReplaced");
	}

	public void attributeReplaced(ServletContextAttributeEvent event) {

		// System.out.println("Ouvidor Geral: attributeReplaced");
	}

	public void attributeRemoved(ServletRequestAttributeEvent srae) {

		// System.out.println("Ouvidor Geral: attributeRemoved");
	}

	public void contextDestroyed(ServletContextEvent sce) {

		// System.out.println("Ouvidor Geral: contextDestroyed");
	}

	public void attributeReplaced(ServletRequestAttributeEvent srae) {

		// System.out.println("Ouvidor Geral: attributeReplaced");
	}

	public void requestInitialized(ServletRequestEvent sre) {

		// System.out.println("Ouvidor Geral: requestInitialized");
	}

}
