package br.inf.bluestar.agenda.dominio.repositorios;

import java.sql.SQLException;
import java.util.List;

import br.inf.bluestar.agenda.dominio.entidades.Contato;
import br.inf.bluestar.agenda.infraestrutura.factory.ConexaoFabrica;
import br.inf.bluestar.agenda.infraestrutura.persistencia.ContatoDAOJDBC;

public class ContatoRepositorio {

	private ContatoDAOJDBC dao = new ContatoDAOJDBC();

	public List<Contato> listarTodos() throws SQLException {

		dao.setConexao(ConexaoFabrica.obtemConexaoProducao());

		return dao.buscarTodos();
	}

	public Contato salvarOuAtualizar(Contato contato) throws SQLException {
		dao.setConexao(ConexaoFabrica.obtemConexaoProducao());

		return dao.salvarOuAtualizar(contato);
	}

	public void excluir(Contato contato) throws SQLException {
		dao.setConexao(ConexaoFabrica.obtemConexaoProducao());

		dao.excluir(contato);

	}

	public Contato obterContato(Long id) throws SQLException {
		dao.setConexao(ConexaoFabrica.obtemConexaoProducao());

		return dao.buscarPorId(id, false);
	}

}
