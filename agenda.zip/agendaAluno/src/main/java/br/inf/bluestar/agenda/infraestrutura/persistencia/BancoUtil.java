package br.inf.bluestar.agenda.infraestrutura.persistencia;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletContext;

import br.inf.bluestar.agenda.infraestrutura.factory.ConexaoFabrica;

public class BancoUtil {

	/**
	 * Arquivo com os comandos SQL para iniciar o banco de dados
	 */
	public static final String	SQL_INSTALACAO_BANCO			= "src/main/webapp/WEB-INF/database.sql";
	public static final String	SQL_INSTALACAO_BANCO_SERVIDOR	= "/WEB-INF/database.sql";
	private static InputStream	stream;

	public static void instalaBanco() {

		try {
			stream = new FileInputStream(SQL_INSTALACAO_BANCO);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		executarSQL();

	}

	public static void main(String[] args) {

		instalaBanco();

	}

	public static void instalaBanco(ServletContext contexto) {

		stream = contexto.getResourceAsStream(SQL_INSTALACAO_BANCO_SERVIDOR);

		executarSQL();

	}

	private static void executarSQL() {

		try {

			BufferedReader br = new BufferedReader(new InputStreamReader(stream));
			StringBuilder sb = new StringBuilder();

			System.out.println("************************ Instalando Banco de Dados ************************\n\n\n");

			String strLine;
			while ((strLine = br.readLine()) != null) {
				sb.append(strLine);
				System.out.println(strLine);
			}

			try {
				Connection conexao = ConexaoFabrica.obtemConexaoProducao();
				Statement stmt = conexao.createStatement();
				stmt.executeUpdate(sb.toString());
				stmt.executeUpdate("INSERT INTO contatos (nome, telefone, celular, email, endereco, cidade, uf, sexo) VALUES ('Paulo H','33213030', '81818181', 'palerique@gmail.com', 'Rua 36', 'Águas Claras', 'DF', 'm');");
				stmt.executeUpdate("INSERT INTO usuarios (login, senha) VALUES ('teste','123456');");
				conexao.commit();
				conexao.close();
			} catch (SQLException e) {
				e.printStackTrace();
				throw new Exception("Problema executar sql do arquivo", e);
			}
			System.out.println("\n\n\n************************ Banco de Dados Instalado com Sucesso ************************");
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}

	}

}
