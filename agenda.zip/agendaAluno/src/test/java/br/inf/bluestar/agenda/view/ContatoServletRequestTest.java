package br.inf.bluestar.agenda.view;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import br.inf.bluestar.agenda.uteis.BaseTestes;

import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;
import com.gargoylesoftware.htmlunit.HttpMethod;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.util.NameValuePair;

public class ContatoServletRequestTest extends BaseTestes {

	private static HtmlPage	pagina;
	private static String	textoPagina;

	@Before
	public void setup() throws FailingHttpStatusCodeException, MalformedURLException, IOException {

		efetuarLogin();
		cadastrarContato();
	}

	public void cadastrarContato() throws FailingHttpStatusCodeException, MalformedURLException, IOException {

		// Preparo a requisição
		WebRequest requestSettings = new WebRequest(new URL("http://localhost:9091/agenda/contato"), HttpMethod.POST);

		// adiciono os parâmetros na requisição
		requestSettings.setRequestParameters(new ArrayList<NameValuePair>());
		requestSettings.getRequestParameters().add(new NameValuePair("nome", "Paulo"));
		requestSettings.getRequestParameters().add(new NameValuePair("email", "palerique@gmail.com"));
		requestSettings.getRequestParameters().add(new NameValuePair("telefone", "33213030"));
		requestSettings.getRequestParameters().add(new NameValuePair("celular", "81818181"));
		requestSettings.getRequestParameters().add(new NameValuePair("endereco", "Rua da Alegria"));
		requestSettings.getRequestParameters().add(new NameValuePair("cidade", "Taguatinga"));
		requestSettings.getRequestParameters().add(new NameValuePair("uf", "DF"));
		requestSettings.getRequestParameters().add(new NameValuePair("dataNascimento", "16/01/1984"));
		requestSettings.getRequestParameters().add(new NameValuePair("sexo", "m"));
		requestSettings.getRequestParameters().add(new NameValuePair("acao", "salvar"));

		// Agora sim acesso a página
		pagina = navegador.getPage(requestSettings);

		textoPagina = preparaXML(pagina);
	}

	public void efetuarLogin() throws FailingHttpStatusCodeException, MalformedURLException, IOException {

		// Preparo a requisição
		WebRequest requestSettings = new WebRequest(new URL("http://localhost:9091/agenda/login"), HttpMethod.POST);

		// adiciono os parâmetros na requisição
		requestSettings.setRequestParameters(new ArrayList<NameValuePair>());
		requestSettings.getRequestParameters().add(new NameValuePair("login", "teste"));
		requestSettings.getRequestParameters().add(new NameValuePair("senha", "123456"));

		// Agora sim acesso a página
		pagina = navegador.getPage(requestSettings);

		textoPagina = preparaXML(pagina);
	}

	@Test
	@Ignore
	public void respostaDeveConterTelefone() throws Exception {

		efetuarLogin();

		System.out.println(textoPagina);

		assertTrue(textoPagina.contains("33213030"));

	}

	@Test
	@Ignore
	public void respostaDeveConterCelular() throws Exception {

		assertTrue(textoPagina.contains("81818181"));

	}

	@Test
	@Ignore
	public void respostaDeveConterEndereco() throws Exception {

		assertTrue(textoPagina.contains("Rua da Alegria"));

	}

	@Test
	@Ignore
	public void respostaDeveConterCidade() throws Exception {

		assertTrue(textoPagina.contains("Taguatinga"));

	}

	@Test
	@Ignore
	public void respostaDeveConterUF() throws Exception {

		assertTrue(textoPagina.contains("DF"));

	}

	@Test
	@Ignore
	public void respostaDeveConterNome() throws Exception {

		assertTrue(textoPagina.contains("Paulo"));

	}

	@Test
	@Ignore
	public void respostaDeveConterEmail() throws Exception {

		assertTrue(textoPagina.contains("palerique@gmail.com"));

	}

	@Test
	@Ignore
	public void respostaDeveConterDataNascimento() throws Exception {

		assertTrue(textoPagina.contains("16/01/1984"));

	}

	@Test
	@Ignore
	public void respostaDeveConterSexo() throws Exception {

		assertTrue(textoPagina.contains("MASCULINO"));

	}

	@Test
	@Ignore
	public void deveAceitarRequisicaoGETERedirecionarParaAListaDeContatos() throws Exception {

		pagina = navegador.getPage("http://localhost:9091/agenda/contato");

		assertNotNull(pagina.getBody());

		assertEquals("O titulo da pagina deve ter um texto como no exercício", "Lista de Contatos", pagina.getTitleText());

		String menuHeader = "<nav class=\"menu_main\"> <ul> <li> <a href=\"index.jsp\"> Início </a> </li> <li> <a href=\"form.jsp\"> Cadastrar </a> </li> <li class=\"active\"> <a href=\"lista.jsp\"> Listar </a> </li> </ul> </nav>";

		// System.out.println(textoPagina);

		assertTrue("O index deve ter um menu", textoPagina.contains(menuHeader));

		String menuFooter = "<nav class=\"menu_bottom\"> <ul> <li> <a href=\"index.jsp\"> Início </a> </li> <li> <a href=\"form.jsp\"> Cadastrar </a> </li> <li class=\"active\"> <a href=\"lista.jsp\"> Listar </a> </li> </ul> </nav>";

		// System.out.println(textoPagina);

		assertTrue("O index deve ter um menu", textoPagina.contains(menuFooter));

		String headerTabela = "<table class=\"table\"> <tbody> <tr> <th> Nome </th> <th> Sexo </th> <th> Telefone </th> <th> Celular </th> <th> E-mail </th> <th> Data de Nascimento </th> <th> Endereço </th> <th> Cidade </th> <th> UF </th> <th> Editar </th> <th> Excluir </th> </tr>";

		assertTrue("O index deve ter uma tabela com todas as colunas solicitadas e ao menos uma linha preenchida", textoPagina.contains(headerTabela));

	}

}