package br.inf.bluestar.agenda.uteis;

import java.io.File;

import org.apache.catalina.LifecycleState;
import org.apache.catalina.startup.Tomcat;
import org.jboss.shrinkwrap.api.Filters;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.exporter.ZipExporter;
import org.jboss.shrinkwrap.api.importer.ExplodedImporter;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.jboss.shrinkwrap.resolver.api.DependencyResolvers;
import org.jboss.shrinkwrap.resolver.api.maven.MavenDependencyResolver;
import org.jboss.shrinkwrap.resolver.api.maven.filter.ScopeFilter;
import org.junit.AfterClass;
import org.junit.BeforeClass;

import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlPage;

/**
 * Classe base para outras classes que fazem teste de aceitação na aplicação da
 * agenda.
 */
public class BaseTestes {

	private static final String TARGET_SHRINKWRAP_AGENDA_WAR = "target/shrinkwrap/agenda.war";

	/**
	 * Navegador utilizado para testar os servlets.
	 */
	protected static WebClient navegador;

	/**
	 * Container de servlets embutido
	 */
	protected static Tomcat servidor;

	/**
	 * Na inicialização carrega container de servlet e o banco de dados para
	 * realizar os testes.
	 */
	@BeforeClass
	public static void inicializar() throws Exception {

		servidor = new Tomcat();
		servidor.setPort(9091);
		servidor.setBaseDir("target/temp");

		// Gera o arquivo .war com as classes.
		gerarArquivoWar();

		File arquivoWar = new File(TARGET_SHRINKWRAP_AGENDA_WAR);
		servidor.addWebapp(servidor.getHost(), "/agenda",
				arquivoWar.getAbsolutePath());

		servidor.start();

		navegador = new WebClient();

	}

	/**
	 * Gera arquivo zipado com a aplicação e salva no diretório target.
	 */
	private static void gerarArquivoWar() throws Exception {

		// Cria diretorio shrinkwrap dentro de target/
		final File webAppDir = new File("target/shrinkwrap");

		if (!webAppDir.exists())
			webAppDir.mkdirs();

		WebArchive war = ShrinkWrap.create(WebArchive.class,
				TARGET_SHRINKWRAP_AGENDA_WAR);

		war.addAsLibraries(DependencyResolvers
				.use(MavenDependencyResolver.class)
				.includeDependenciesFromPom("pom.xml")
				.resolveAsFiles(new ScopeFilter("compile")));

		// Adiciona todas as classes necessárias
		war.addPackages(true, "br.inf.bluestar.agenda");

		// Importa todos os arquivos dentro de webaap, como js, img, css, jsps.
		ExplodedImporter exploded = ShrinkWrap.create(JavaArchive.class).as(
				ExplodedImporter.class);
		exploded.importDirectory("src/main/webapp");

		// Junta com as classes já adicionadas.
		war.merge(exploded.as(JavaArchive.class), Filters.includeAll());

		/*
		 * Exportando aplicação com um arquivo .war
		 */
		final File webappFile = new File(TARGET_SHRINKWRAP_AGENDA_WAR);
		war.as(ZipExporter.class).exportTo(webappFile, true);
	}

	@AfterClass
	public static void encerrar() throws Exception {

		/*
		 * Para o servidor ser "desligado", ele deve ser parado e destruido. A
		 * API do Tomcat Embutido permite que você acesse o estado do servidor e
		 * ver se ele parou ou foi destruido.
		 */
		if (servidor.getServer() != null
				&& servidor.getServer().getState() != LifecycleState.DESTROYED) {
			if (servidor.getServer().getState() != LifecycleState.STOPPED) {
				servidor.stop();
			}
			servidor.destroy();
		}
	}

	protected static String preparaXML(HtmlPage pagina) {

		return pagina.asXml().replace("\b", "").replace("\f", "")
				.replace("\n", "").replace("\r", "").replace("\t", "")
				.replace("            ", " ").replace("           ", " ")
				.replace("          ", " ").replace("         ", " ")
				.replace("        ", " ").replace("       ", " ")
				.replace("      ", " ").replace("     ", " ")
				.replace("    ", " ").replace("   ", " ").replace("  ", " ")
				.trim();

	}

}
