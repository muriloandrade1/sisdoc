package br.inf.bluestar.agenda.dominio;

import java.util.Calendar;

import junit.framework.Assert;

import org.junit.Test;

import br.inf.bluestar.agenda.dominio.entidades.Contato;
import br.inf.bluestar.agenda.dominio.entidades.Sexo;

public class ContatoTest {

	@Test
	public void deveInstanciarContato() {

		Contato c = new Contato();

		Assert.assertNotNull(c);
	}

	@Test
	public void deveTerOsMetodosGetESet() {

		Contato c = new Contato();

		String nome = "Paulo";
		String telefone = "33218181";
		String celular = "81818181";
		String email = "ph@ph.com.br";
		String endereco = "Rua da Alegria";
		String cidade = "Taguatinga";
		String uf = "DF";
		Calendar cal = Calendar.getInstance();
		cal.set(1984, 0, 16);
		Sexo s = Sexo.MASCULINO;

		c.setNome(nome);
		c.setTelefone(telefone);
		c.setCelular(celular);
		c.setEmail(email);
		c.setEndereco(endereco);
		c.setCidade(cidade);
		c.setUf(uf);
		c.setDataDeNascimento(cal);
		c.setSexo(s);

		Assert.assertEquals(nome, c.getNome());
		Assert.assertEquals(telefone,
							c.getTelefone());
		Assert.assertEquals(celular,
							c.getCelular());
		Assert.assertEquals(email, c.getEmail());
		Assert.assertEquals(endereco,
							c.getEndereco());
		Assert.assertEquals(cidade, c.getCidade());
		Assert.assertEquals(uf, c.getUf());
		Assert.assertEquals(cal,
							c.getDataDeNascimento());
		Assert.assertEquals(s, c.getSexo());
	}

	@Test(expected = RuntimeException.class)
	public void deveVerficarComprimentoMinimoDoNome() {

		Contato c = new Contato();

		String nome = "PH";

		c.setNome(nome);
	}

	@Test
	public void deveExibirMensagemApropriadaParaComprimentoMinimoDoNome() {

		Contato c = new Contato();

		String nome = "PH";
		try {
			c.setNome(nome);
		} catch (Exception e) {
			Assert.assertEquals("Nome deve ter ao menos 5 caracteres",
								e.getMessage());
		}
	}

	@Test(expected = RuntimeException.class)
	public void deveValidarEmail() {

		Contato c = new Contato();

		String emailInvalido = "PH";

		c.setEmail(emailInvalido);
	}

	@Test
	public void deveExibirMensagemApropriadaParaEmailInvalido() {

		Contato c = new Contato();

		String emailInvalido = "PH";

		try {
			c.setEmail(emailInvalido);
		} catch (Exception e) {
			Assert.assertEquals("Endereço de E-mail Inválido",
								e.getMessage());
		}
	}

}
