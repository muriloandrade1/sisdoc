package br.inf.bluestar.agenda.view;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.net.MalformedURLException;

import br.inf.bluestar.agenda.uteis.BaseTestes;

import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;
import com.gargoylesoftware.htmlunit.html.HtmlPage;

public class ListaJSPTest extends BaseTestes {

	private static HtmlPage	pagina;
	private static String	textoPagina;

	public static void setup() throws FailingHttpStatusCodeException, MalformedURLException, IOException {

		pagina = navegador.getPage("http://localhost:9091/agenda/lista.jsp");

		textoPagina = preparaXML(pagina);
	}

	public void verificaMensagemTitleForm() throws Exception {

		assertEquals("O titulo da pagina deve ter um texto como no exercício", "Lista de Contatos", pagina.getTitleText());
	}

	public void verificaBodyForm() throws Exception {

		assertTrue("A página deve ter um <body>", pagina.getBody() != null);
	}

	public void corpoFormDeveTerEncodingUtf8() throws Exception {

		assertTrue("O index deve estar configurado para encoding=\"utf-8\"", textoPagina.contains("xml version=\"1.0\" encoding=\"UTF-8\""));

		assertTrue("O index deve estar configurado para encoding=\"utf-8\"", textoPagina.contains("charset=UTF-8"));

	}

	public void corpoFormDeveTerLangPt() throws Exception {

		assertTrue("O index deve estar configurado com lang pt", textoPagina.contains("<html lang=\"pt\""));

	}

	public void corpoFormDeveTerMenuHeader() throws Exception {

		String menu = "<nav class=\"menu_main\"> <ul> <li> <a href=\"index.jsp\"> Início </a> </li> <li> <a href=\"form.jsp\"> Cadastrar </a> </li> <li class=\"active\"> <a href=\"lista.jsp\"> Listar </a> </li> </ul> </nav>";

		// System.out.println(textoPagina);

		assertTrue("O index deve ter um menu", textoPagina.contains(menu));

	}

	public void corpoFormDeveTerMenuFooter() throws Exception {

		String menu = "<nav class=\"menu_bottom\"> <ul> <li> <a href=\"index.jsp\"> Início </a> </li> <li> <a href=\"form.jsp\"> Cadastrar </a> </li> <li class=\"active\"> <a href=\"lista.jsp\"> Listar </a> </li> </ul> </nav>";

		// System.out.println(textoPagina);

		assertTrue("O index deve ter um menu", textoPagina.contains(menu));

	}

	public void corpoFormDeveTerTabelaComAsColunasSolicitadas() throws Exception {

		String headerTabela = "<table class=\"table\"> <tbody> <tr> <th> Nome </th> <th> Sexo </th> <th> Telefone </th> <th> Celular </th> <th> E-mail </th> <th> Data de Nascimento </th> <th> Endereço </th> <th> Cidade </th> <th> UF </th> <th> Editar </th> <th> Excluir </th> </tr>";

		assertTrue("O index deve ter uma tabela com todas as colunas solicitadas e ao menos uma linha preenchida", textoPagina.contains(headerTabela));

	}

}
