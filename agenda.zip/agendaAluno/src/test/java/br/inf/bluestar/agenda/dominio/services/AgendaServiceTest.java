package br.inf.bluestar.agenda.dominio.services;

import java.sql.SQLException;
import java.util.Calendar;
import java.util.List;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import br.inf.bluestar.agenda.aplicacao.services.AgendaService;
import br.inf.bluestar.agenda.dominio.builders.ContatoBuilder;
import br.inf.bluestar.agenda.dominio.entidades.Contato;
import br.inf.bluestar.agenda.infraestrutura.persistencia.BancoUtil;

public class AgendaServiceTest {

	AgendaService service = new AgendaService();

	@Before
	public void setup() {

		BancoUtil.instalaBanco();
	}

	@After
	public void tearDown() {

		BancoUtil.instalaBanco();
	}

	@Test
	public void testSalvarContato() throws SQLException {

		List<Contato> contatos = service.obterContatos();
		int tamanhoLista = contatos.size();

		Calendar dataNascimento = Calendar.getInstance();
		dataNascimento.set(1984, 0, 16);

		Contato c = new ContatoBuilder().comNome("Paulo Henrique")
				.celular("81818181").telefone("332130L30L")
				.cidade("Águas Claras").endereco("Rua 36")
				.email("palerique@gmail.com").nascidoEm(dataNascimento)
				.uf("DF").constroi();

		Contato c2 = service.salvarOuAtualizar(c);

		contatos = service.obterContatos();

		Assert.assertEquals(c.getNome(), c2.getNome());
		Assert.assertEquals(c.getCelular(), c2.getCelular());
		Assert.assertEquals(c.getCidade(), c2.getCidade());
		Assert.assertEquals(c.getEmail(), c2.getEmail());
		Assert.assertEquals(c.getEndereco(), c2.getEndereco());
		Assert.assertEquals(c.getTelefone(), c2.getTelefone());
		Assert.assertEquals(c.getUf(), c2.getUf());
		Assert.assertEquals(c.getDataDeNascimento(), c2.getDataDeNascimento());
		Assert.assertNotNull(c2.getId());
		Assert.assertEquals(tamanhoLista + 1, contatos.size());

	}

	@Test
	public void testListarContatos() throws SQLException {

		List<Contato> contatos = service.obterContatos();
		int tamanhoLista = contatos.size();

		Calendar dataNascimento = Calendar.getInstance();
		dataNascimento.set(1984, 0, 16);

		Contato c = new ContatoBuilder().comNome("Paulo Henrique")
				.celular("81818181").telefone("332130L30L")
				.cidade("Águas Claras").endereco("Rua 36")
				.email("palerique@gmail.com").nascidoEm(dataNascimento)
				.uf("DF").constroi();

		Contato c2 = service.salvarOuAtualizar(c);

		contatos = service.obterContatos();

		Assert.assertEquals(c.getNome(), c2.getNome());
		Assert.assertEquals(c.getCelular(), c2.getCelular());
		Assert.assertEquals(c.getCidade(), c2.getCidade());
		Assert.assertEquals(c.getEmail(), c2.getEmail());
		Assert.assertEquals(c.getEndereco(), c2.getEndereco());
		Assert.assertEquals(c.getTelefone(), c2.getTelefone());
		Assert.assertEquals(c.getUf(), c2.getUf());
		Assert.assertEquals(c.getDataDeNascimento(), c2.getDataDeNascimento());
		Assert.assertNotNull(c2.getId());
		Assert.assertEquals(tamanhoLista + 1, contatos.size());

	}

	@Test
	public void testEditarContato() throws SQLException {

		Contato c2 = service.obterContato(0L);

		String nomeAntigo = c2.getNome();
		String celularAntigo = c2.getCelular();
		String cidadeAntiga = c2.getCidade();
		String emailAntigo = c2.getEmail();
		String enderecoAntigo = c2.getEndereco();
		String telefoneAntigo = c2.getTelefone();
		String ufAntiga = c2.getUf();

		c2.setNome("Editado");
		c2.setCelular("91919191");
		c2.setCidade("Editado");
		c2.setEmail("a@a.com");
		c2.setEndereco("editado");
		c2.setTelefone("editado");
		c2.setUf("ES");

		service.salvarOuAtualizar(c2);

		Contato c3 = service.obterContato(0L);

		Assert.assertEquals("Editado", c3.getNome());
		Assert.assertEquals("91919191", c3.getCelular());
		Assert.assertEquals("Editado", c3.getCidade());
		Assert.assertEquals("a@a.com", c3.getEmail());
		Assert.assertEquals("editado", c3.getEndereco());
		Assert.assertEquals("editado", c3.getTelefone());
		Assert.assertEquals("ES", c3.getUf());

		c3.setNome(nomeAntigo);
		c3.setCelular(celularAntigo);
		c3.setCidade(cidadeAntiga);
		c3.setEmail(emailAntigo);
		c3.setEndereco(enderecoAntigo);
		c3.setTelefone(telefoneAntigo);
		c3.setUf(ufAntiga);

		service.salvarOuAtualizar(c3);

		Contato c4 = service.obterContato(0L);

		Assert.assertEquals(nomeAntigo, c4.getNome());
		Assert.assertEquals(celularAntigo, c4.getCelular());
		Assert.assertEquals(cidadeAntiga, c4.getCidade());
		Assert.assertEquals(emailAntigo, c4.getEmail());
		Assert.assertEquals(enderecoAntigo, c4.getEndereco());
		Assert.assertEquals(telefoneAntigo, c4.getTelefone());
		Assert.assertEquals(ufAntiga, c4.getUf());
	}

	@Test
	public void testExcluirContato() throws SQLException {

		Contato contato = new Contato();

		contato.setId(0L);

		service.excluir(contato);

		Assert.assertTrue(service.obterContatos().size() == 0L);
	}

	@Test
	public void testObterContato() throws SQLException {

		Contato c4 = service.obterContato(0L);

		Assert.assertNotNull(c4);

	}
}
