package br.inf.bluestar.agenda.uteis;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import br.inf.bluestar.agenda.dominio.uteis.EmailValidator;

public class EmailValidatorTest {

	private static EmailValidator emailValidator;
	private String[] invalidos = new String[] { "mkyong", "mkyong@.com.my",
			"mkyong123@gmail.a", "mkyong123@.com", "mkyong123@.com.com",
			".mkyong@mkyong.com", "mkyong()*@gmail.com", "mkyong@%*.com",
			"mkyong..2002@gmail.com", "mkyong.@gmail.com",
			"mkyong@mkyong@gmail.com", "mkyong@gmail.com.1a" };

	private String[] validos = new String[] { "mkyong@yahoo.com",
			"mkyong-100@yahoo.com", "mkyong.100@yahoo.com",
			"mkyong111@mkyong.com", "mkyong-100@mkyong.net",
			"mkyong.100@mkyong.com.au", "mkyong@1.com", "mkyong@gmail.com.com" };

	@BeforeClass
	public static void initData() {
		emailValidator = new EmailValidator();
	}

	@Test
	public void ValidEmailTest() {

		for (String temp : validos) {
			boolean valid = emailValidator.validate(temp);
			Assert.assertEquals(true, valid);
		}

	}

	@Test
	public void InValidEmailTest() {

		for (String temp : invalidos) {
			boolean valid = emailValidator.validate(temp);
			Assert.assertEquals(false, valid);
		}
	}

}
