package br.inf.bluestar.agenda.view;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.net.MalformedURLException;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import br.inf.bluestar.agenda.uteis.BaseTestes;

import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;
import com.gargoylesoftware.htmlunit.html.HtmlPage;

public class IndexJSPTest extends BaseTestes {

	private static HtmlPage pagina;
	private static String textoPagina;

	@BeforeClass
	public static void setup() throws FailingHttpStatusCodeException,
			MalformedURLException, IOException {

		pagina = navegador.getPage("http://localhost:9091/agenda/index.jsp");

		textoPagina = preparaXML(pagina);
	}

	@Test
	public void verificaMensagemTitleIndex() throws Exception {

		assertEquals("O titulo da pagina deve ter um texto como no exercício",
				"Agenda de Contatos - JSP Básico", pagina.getTitleText());
	}

	@Test
	public void verificaBodyIndex() throws Exception {

		assertTrue("A página deve ter um <body>", pagina.getBody() != null);
	}

	@Test
	public void corpoIndexDeveTerEncodingUtf8() throws Exception {

		assertTrue(
				"O index.jsp deve estar configurado para encoding=\"utf-8\"",
				textoPagina.contains("charset=UTF-8"));

	}

	@Test
	public void corpoIndexDeveTerLangPt() throws Exception {

		assertTrue("O index.jsp deve estar configurado com lang pt",
				textoPagina.contains("<html lang=\"pt\""));

	}

	@Test
	@Ignore
	public void corpoIndexDeveTerMenuHeader() throws Exception {

		String menu = "<nav class=\"menu_main\"> <ul> <li class=\"active\"> <a href=\"index.jsp\"> Início </a> </li> <li> <a href=\"form.jsp\"> Cadastrar </a> </li> <li> <a href=\"lista.jsp\"> Listar </a> </li> </ul> </nav>";

		// System.out.println(textoPagina);

		assertTrue("O index.jsp deve ter um menu", textoPagina.contains(menu));

	}

	@Test
	@Ignore
	public void corpoIndexDeveTerMenuFooter() throws Exception {

		String menu = "<nav class=\"menu_bottom\"> <ul> <li class=\"active\"> <a href=\"index.jsp\"> Início </a> </li> <li> <a href=\"form.jsp\"> Cadastrar </a> </li> <li> <a href=\"lista.jsp\"> Listar </a> </li> </ul> </nav>";

		// System.out.println(textoPagina);

		assertTrue("O index.jsp deve ter um menu", textoPagina.contains(menu));

	}

}
