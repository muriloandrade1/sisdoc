package br.inf.bluestar.agenda.view;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.net.MalformedURLException;

import br.inf.bluestar.agenda.uteis.BaseTestes;

import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;
import com.gargoylesoftware.htmlunit.html.HtmlPage;

public class FormJSPTest extends BaseTestes {

	private static HtmlPage	pagina;
	private static String	textoPagina;

	public static void setup() throws FailingHttpStatusCodeException, MalformedURLException, IOException {

		pagina = navegador.getPage("http://localhost:9091/agenda/form.jsp");

		textoPagina = preparaXML(pagina);
	}

	public void verificaMensagemTitleForm() throws Exception {

		assertEquals("O titulo da pagina deve ter um texto como no exercício", "Formulário de Cadastro de Contatos", pagina.getTitleText());
	}

	public void verificaBodyForm() throws Exception {

		assertTrue("A página deve ter um <body>", pagina.getBody() != null);
	}

	public void corpoFormDeveTerEncodingUtf8() throws Exception {

		assertTrue("O index deve estar configurado para encoding=\"utf-8\"", textoPagina.contains("xml version=\"1.0\" encoding=\"UTF-8\""));

		assertTrue("O index deve estar configurado para encoding=\"utf-8\"", textoPagina.contains("charset=UTF-8"));

	}

	public void corpoFormDeveTerLangPt() throws Exception {

		assertTrue("O index deve estar configurado com lang pt", textoPagina.contains("<html lang=\"pt\""));

	}

	public void corpoFormDeveTerMenuHeader() throws Exception {

		String menu = "<nav class=\"menu_main\"> <ul> <li> <a href=\"index.jsp\"> Início </a> </li> <li class=\"active\"> <a href=\"form.jsp\"> Cadastrar </a> </li> <li> <a href=\"lista.jsp\"> Listar </a> </li> </ul> </nav>";

		// System.out.println(textoPagina);

		assertTrue("O index deve ter um menu", textoPagina.contains(menu));

	}

	public void corpoFormDeveTerMenuFooter() throws Exception {

		String menu = "<nav class=\"menu_bottom\"> <ul> <li> <a href=\"index.jsp\"> Início </a> </li> <li class=\"active\"> <a href=\"form.jsp\"> Cadastrar </a> </li> <li> <a href=\"lista.jsp\"> Listar </a> </li> </ul> </nav>";

		// System.out.println(textoPagina);

		assertTrue("O index deve ter um menu", textoPagina.contains(menu));

	}

	public void corpoFormDeveTerFormularioComOsCamposSolicitados() throws Exception {

		assertTrue("O index deve ter um formulário", textoPagina.contains("<form action=\"contato\" method=\"post\" class=\"form\">"));

		assertTrue(	"O index deve ter um campo para nome",
					textoPagina.contains("<label for=\"nome\"> Nome: </label> <br/> <input type=\"text\" name=\"nome\" id=\"name\" value=\"\"/>"));

		assertTrue(	"O index deve ter um campo para telefone",
					textoPagina.contains("<label for=\"telefone\"> Telefone: </label> <br/> <input type=\"text\" name=\"telefone\" id=\"telefone\" value=\"\"/>"));

		assertTrue(	"O index deve ter um campo para celular",
					textoPagina.contains("<label for=\"celular\"> Celular: </label> <br/> <input type=\"text\" name=\"celular\" id=\"celular\" value=\"\"/>"));

		assertTrue(	"O index deve ter um campo para e-mail",
					textoPagina.contains("<label for=\"email\"> E-mail: </label> <br/> <input type=\"text\" name=\"email\" id=\"email\" value=\"\"/>"));

		assertTrue(	"O index deve ter um campo para data de nascimento",
					textoPagina.contains("<label for=\"dataNascimento\"> Data de Nascimento: </label> <br/> <input type=\"text\" name=\"dataNascimento\" id=\"dataNascimento\" value=\"\"/>"));

		assertTrue(	"O index deve ter um campo para endereço",
					textoPagina.contains("<label for=\"endereco\"> Endereço: </label> <br/> <input type=\"text\" name=\"endereco\" id=\"endereco\" value=\"\"/>"));

		assertTrue(	"O index deve ter um campo para cidade",
					textoPagina.contains("<label for=\"cidade\"> Cidade: </label> <br/> <input type=\"text\" name=\"cidade\" id=\"cidade\" value=\"\"/>"));

		assertTrue(	"O index deve ter um campo para uf",
					textoPagina.contains("<label for=\"uf\"> UF: </label> <br/> <input type=\"text\" name=\"uf\" id=\"uf\" value=\"\"/>"));

		assertTrue(	"O index deve ter um campo para sexo do tipo radio com as opções masculino e feminino",
					textoPagina.contains("<label for=\"radio-choice-1\"> <input type=\"radio\" name=\"sexo\" id=\"radio-choice-1\" tabindex=\"2\" value=\"m\"/> Masculino </label> <br/> <label for=\"radio-choice-2\"> <input type=\"radio\" name=\"sexo\" id=\"radio-choice-2\" tabindex=\"3\" value=\"f\"/> Feminino </label>"));

		assertTrue("O index deve ter um botão para envio do formulário", textoPagina.contains("<button type=\"submit\" class=\"button\">"));

	}
	//
	// @Test
	// public void corpoFormDeveTerTabelaComAsColunasSolicitadas() throws
	// Exception {
	//
	// assertTrue(
	// "O index deve ter uma tabela com todas as colunas solicitadas e ao menos uma linha preenchida",
	// textoPagina.contains("<table class=\"table\"> <tbody> <tr> <th> Nome </th> <th> Telefone </th> <th> Celular </th> <th> E-mail </th> <th> Data de Nascimento </th> <th> Endereço </th> <th> Cidade </th> <th> UF </th> <th> Editar </th> <th> Excluir </th> </tr> <tr> <th>"));
	//
	// assertTrue("O index deve ter uma tabela com todas as colunas solicitadas e ao menos uma linha preenchida",
	// textoPagina.contains("</th> </tr> </tbody> </table>"));
	//
	// }

}
